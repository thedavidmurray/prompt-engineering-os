# Agent Cookbook

**Multi-agent AI systems with Claude Code — 16 chapters, 10 patterns, 10 recipes, 60+ code examples.**

A paid digital product from [Edgeless Labs LLC](https://edgeless.ai). Dark theme, self-contained HTML, no external dependencies.

---

## What's inside

**Part 1 — Foundations**
1. What agents actually are (not what marketers say)
2. The Claude Code agent model — subagents, tools, CLAUDE.md, permissions
3. Agents vs direct tool calls — the decision framework
4. Agent communication patterns — prompt injection, filesystem, structured output

**Part 2 — Patterns**
5. Builder-Validator — build in one agent, validate in another
6. Fan-out / Fan-in — parallel agents with result aggregation
7. Pipeline — sequential transformation chain with stage isolation
8. Ralph Wiggum loop — iterative self-improvement with quality threshold
9. Supervisor — orchestrator delegates to specialized workers
10. Consensus — multiple independent agents vote on decisions

**Part 3 — Production**
11. Error handling and retry strategies — exponential backoff, loop detection, malformed output
12. Context window management — sliding window, summarization, retrieval
13. Cost optimization — model selection, prompt caching, token budgets
14. Testing multi-agent systems — unit, behavioral, golden output, chaos
15. Monitoring and observability — structured logging, cost tracking, alerting

**Part 4 — Recipes**
16. 10 ready-to-use configurations: code review, research synthesis, code migration,
    test generation, deployment verification, documentation, security audit,
    performance optimization, data pipeline, content generation

---

## Files

| File | Description |
|------|-------------|
| `agent-cookbook.html` | Complete self-contained guide (152KB) |
| `README.md` | This file |
| `LICENSE` | MIT License |

---

## Usage

Open `agent-cookbook.html` in any modern browser. No build step, no server, no external dependencies.

To export PDF: Chrome → Print → Save as PDF. Enable "Background graphics" to preserve the dark theme.

---

## License

MIT License. Copyright 2026 Edgeless Labs LLC.

Code examples are free to use commercially. See LICENSE for full terms.

---

*Edgeless Labs LLC — edgeless.ai*
