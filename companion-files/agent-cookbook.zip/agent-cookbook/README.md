# The Agent Cookbook

**Practical guide to building production multi-agent systems with Claude Code.**

A single-file HTML guide covering patterns, recipes, and hard-won lessons from building real agents that ship.

## Contents

- **Part I: Foundations** — Agent architecture, the skill system, hooks and automation
- **Part II: Patterns** — Builder-Validator pairs, progressive disclosure, subagent orchestration, the Ralph Wiggum Loop, session planning
- **Part III: Production** — Completion verification, memory systems, error recovery, rate limiting and cost control
- **Part IV: Recipes** — Code review agent, research agent, deployment agent, content pipeline agent

## Format

Single HTML file (`agent-cookbook.html`) — open in any browser. Dark theme, optimized for reading and printing.

## Usage

Open `agent-cookbook.html` in a browser. No build step, no dependencies, no server required.

---

© 2026 Edgeless Labs LLC. All rights reserved.
