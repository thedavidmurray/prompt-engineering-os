def reverse_string(s: str) -> str:
    """Return the reverse of string s.

    reverse_string("hello") -> "olleh"
    reverse_string("") -> ""
    reverse_string("a") -> "a"
    """
    return s[::-1]
