#!/usr/bin/env bash
# prompt-test.sh — CLI for running prompt test suites
# Copyright 2026 Edgeless Labs LLC — MIT License
#
# Usage:
#   ./framework/prompt-test.sh run <test_spec.yaml> [options]
#   ./framework/prompt-test.sh run-all <dir/> [options]
#   ./framework/prompt-test.sh validate <test_spec.yaml>
#   ./framework/prompt-test.sh list <test_spec.yaml>
#
# Options:
#   --model <model>           Override model in spec (default: claude-3-5-haiku-20241022)
#   --verbose                 Print full request/response for each test
#   --fail-threshold <0-1>    Fail exit code if pass rate below threshold (default: 1.0)
#   --output <file>           Write JSON results to file
#   --max-concurrency <n>     Max parallel test runs (default: 3)
#   --timeout <seconds>       Per-request timeout (default: 30)
#   --dry-run                 Print test plan without executing

set -euo pipefail

# ── Constants ──────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FRAMEWORK_DIR="$SCRIPT_DIR"
VERSION="1.0.0"
DEFAULT_MODEL="claude-3-5-haiku-20241022"
DEFAULT_TIMEOUT=30
DEFAULT_CONCURRENCY=3
DEFAULT_FAIL_THRESHOLD="1.0"
RESULTS_DIR="${PTF_RESULTS_DIR:-./results}"

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# ── Utilities ─────────────────────────────────────────────────────────────────
log()    { echo -e "${BLUE}[ptf]${RESET} $*"; }
ok()     { echo -e "${GREEN}[pass]${RESET} $*"; }
fail()   { echo -e "${RED}[fail]${RESET} $*"; }
warn()   { echo -e "${YELLOW}[warn]${RESET} $*"; }
header() { echo -e "\n${BOLD}${CYAN}$*${RESET}"; }
die()    { echo -e "${RED}[error]${RESET} $*" >&2; exit 2; }

require_cmd() {
    command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"
}

require_env() {
    if [[ -z "${!1:-}" ]]; then
        die "Required environment variable not set: $1"
    fi
}

# ── Dependency checks ─────────────────────────────────────────────────────────
check_deps() {
    require_cmd curl
    require_cmd python3

    # yq or python-based YAML parsing — we use python3 for portability
    python3 -c "import yaml" 2>/dev/null || die "Python yaml module not found. Run: pip install pyyaml"
}

# ── YAML parsing via python3 ───────────────────────────────────────────────────
yaml_get() {
    # yaml_get <file> <dotted.key> [default]
    local file="$1" key="$2" default="${3:-}"
    python3 - <<EOF
import yaml, sys
try:
    with open('$file') as f:
        data = yaml.safe_load(f)
    keys = '$key'.split('.')
    val = data
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        else:
            val = None
        if val is None:
            break
    if val is None:
        print('$default')
    else:
        print(val)
except Exception as e:
    print('$default', file=sys.stderr)
    print('$default')
EOF
}

yaml_test_count() {
    local file="$1"
    python3 - <<EOF
import yaml
with open('$file') as f:
    data = yaml.safe_load(f)
tests = data.get('tests', [])
print(len(tests))
EOF
}

# ── API call helpers ───────────────────────────────────────────────────────────
detect_provider() {
    local model="$1"
    case "$model" in
        claude-*) echo "anthropic" ;;
        gpt-*|o1-*|o3-*) echo "openai" ;;
        *) echo "anthropic" ;;
    esac
}

call_anthropic() {
    local model="$1" system_prompt="$2" user_input="$3" timeout="$4"

    require_env ANTHROPIC_API_KEY

    local payload
    payload=$(python3 -c "
import json, sys
data = {
    'model': '$model',
    'max_tokens': 2048,
    'messages': [{'role': 'user', 'content': json.loads(sys.argv[1])}]
}
if sys.argv[2]:
    data['system'] = sys.argv[2]
print(json.dumps(data))
" "$user_input" "$system_prompt")

    local response http_code
    response=$(curl -s -w "\n%{http_code}" \
        --max-time "$timeout" \
        -X POST "https://api.anthropic.com/v1/messages" \
        -H "x-api-key: $ANTHROPIC_API_KEY" \
        -H "anthropic-version: 2023-06-01" \
        -H "content-type: application/json" \
        -d "$payload" 2>&1)

    http_code=$(echo "$response" | tail -n1)
    local body
    body=$(echo "$response" | head -n-1)

    if [[ "$http_code" != "200" ]]; then
        echo "API_ERROR: HTTP $http_code — $(echo "$body" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('error',{}).get('message','unknown'))" 2>/dev/null || echo "$body")"
        return 1
    fi

    echo "$body" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['content'][0]['text'])"
}

call_openai() {
    local model="$1" system_prompt="$2" user_input="$3" timeout="$4"

    require_env OPENAI_API_KEY

    local messages
    messages=$(python3 -c "
import json, sys
msgs = []
if sys.argv[2]:
    msgs.append({'role': 'system', 'content': sys.argv[2]})
msgs.append({'role': 'user', 'content': sys.argv[1]})
print(json.dumps(msgs))
" "$user_input" "$system_prompt")

    local payload
    payload=$(python3 -c "
import json, sys
print(json.dumps({'model': '$model', 'messages': json.loads(sys.argv[1]), 'max_tokens': 2048}))
" "$messages")

    local response http_code
    response=$(curl -s -w "\n%{http_code}" \
        --max-time "$timeout" \
        -X POST "https://api.openai.com/v1/chat/completions" \
        -H "Authorization: Bearer $OPENAI_API_KEY" \
        -H "content-type: application/json" \
        -d "$payload" 2>&1)

    http_code=$(echo "$response" | tail -n1)
    local body
    body=$(echo "$response" | head -n-1)

    if [[ "$http_code" != "200" ]]; then
        echo "API_ERROR: HTTP $http_code"
        return 1
    fi

    echo "$body" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['choices'][0]['message']['content'])"
}

call_model() {
    local model="$1" system_prompt="$2" user_input="$3" timeout="$4"
    local provider
    provider=$(detect_provider "$model")

    case "$provider" in
        anthropic) call_anthropic "$model" "$system_prompt" "$user_input" "$timeout" ;;
        openai)    call_openai    "$model" "$system_prompt" "$user_input" "$timeout" ;;
        *) die "Unknown provider for model: $model" ;;
    esac
}

# ── Assertion evaluation ───────────────────────────────────────────────────────
# Returns: "pass" or "fail: <reason>"
evaluate_assertion() {
    local assertion_json="$1" output="$2"

    python3 - <<'PYEOF'
import sys, json, re

assertion = json.loads(sys.argv[1])
output = sys.argv[2]
atype = assertion.get('type', '')

def pass_result():
    print("pass")
    sys.exit(0)

def fail_result(reason):
    print(f"fail: {reason}")
    sys.exit(0)

if atype == 'contains':
    value = assertion.get('value', '')
    if assertion.get('case_insensitive', False):
        if value.lower() in output.lower():
            pass_result()
        else:
            fail_result(f"output does not contain '{value}' (case-insensitive)")
    else:
        if value in output:
            pass_result()
        else:
            fail_result(f"output does not contain '{value}'")

elif atype == 'not_contains':
    value = assertion.get('value', '')
    if assertion.get('case_insensitive', False):
        if value.lower() not in output.lower():
            pass_result()
        else:
            fail_result(f"output contains forbidden string '{value}'")
    else:
        if value not in output:
            pass_result()
        else:
            fail_result(f"output contains forbidden string '{value}'")

elif atype == 'exact_match':
    expected = assertion.get('value', '')
    if output.strip() == expected.strip():
        pass_result()
    else:
        fail_result(f"expected '{expected}', got '{output[:100]}'")

elif atype == 'fuzzy_match':
    expected = assertion.get('value', '')
    threshold = float(assertion.get('threshold', 0.8))
    # Simple character-level similarity
    from difflib import SequenceMatcher
    ratio = SequenceMatcher(None, output.lower(), expected.lower()).ratio()
    if ratio >= threshold:
        pass_result()
    else:
        fail_result(f"similarity {ratio:.2f} below threshold {threshold}")

elif atype == 'regex':
    pattern = assertion.get('pattern', '')
    flags = re.IGNORECASE if assertion.get('case_insensitive', False) else 0
    if re.search(pattern, output, flags):
        pass_result()
    else:
        fail_result(f"output does not match pattern '{pattern}'")

elif atype == 'json_valid':
    try:
        json.loads(output)
        pass_result()
    except json.JSONDecodeError as e:
        fail_result(f"invalid JSON: {e}")

elif atype == 'json_schema':
    try:
        data = json.loads(output)
    except json.JSONDecodeError as e:
        fail_result(f"invalid JSON: {e}")
    schema = assertion.get('schema', {})
    required = schema.get('required', [])
    properties = schema.get('properties', {})
    for field in required:
        if field not in data:
            fail_result(f"missing required field: {field}")
    for field, spec in properties.items():
        if field in data:
            expected_type = spec.get('type')
            if expected_type:
                type_map = {'string': str, 'number': (int, float), 'boolean': bool,
                           'array': list, 'object': dict, 'integer': int}
                if expected_type in type_map:
                    if not isinstance(data[field], type_map[expected_type]):
                        fail_result(f"field '{field}' expected type {expected_type}")
    pass_result()

elif atype == 'not_empty':
    if output.strip():
        pass_result()
    else:
        fail_result("output is empty")

elif atype == 'max_length':
    limit = int(assertion.get('value', 1000))
    if len(output) <= limit:
        pass_result()
    else:
        fail_result(f"output length {len(output)} exceeds limit {limit}")

elif atype == 'min_length':
    minimum = int(assertion.get('value', 1))
    if len(output) >= minimum:
        pass_result()
    else:
        fail_result(f"output length {len(output)} below minimum {minimum}")

elif atype in ('llm_judge', 'rubric'):
    # LLM assertions are handled separately via evaluate.py
    # The shell script marks them as 'deferred' and they are scored in post-processing
    print("deferred:llm_judge")
    sys.exit(0)

else:
    fail_result(f"unknown assertion type: {atype}")

PYEOF "$assertion_json" "$output"
}

# ── Test runner ────────────────────────────────────────────────────────────────
run_single_test() {
    local spec_file="$1" test_index="$2" model="$3" verbose="$4" timeout="$5"

    python3 - <<'PYEOF'
import sys, json, yaml, subprocess, os, time

spec_file = sys.argv[1]
test_index = int(sys.argv[2])
model = sys.argv[3]
verbose = sys.argv[4] == 'true'
timeout = int(sys.argv[5])

with open(spec_file) as f:
    spec = yaml.safe_load(f)

test = spec['tests'][test_index]
test_name = test.get('name', f'test_{test_index}')
input_text = test.get('input', '')
assertions = test.get('assertions', [])

# Load prompt template if specified
system_prompt = ''
prompt_template = spec.get('prompt_template') or test.get('prompt_template')
if prompt_template:
    # Resolve relative to spec file location
    base_dir = os.path.dirname(os.path.abspath(spec_file))
    template_path = os.path.join(base_dir, prompt_template)
    if os.path.exists(template_path):
        with open(template_path) as f:
            system_prompt = f.read().strip()
    else:
        # Try relative to cwd
        if os.path.exists(prompt_template):
            with open(prompt_template) as f:
                system_prompt = f.read().strip()

# Apply variable substitution in input
variables = test.get('variables', {})
for k, v in variables.items():
    input_text = input_text.replace(f'{{{{{k}}}}}', str(v))

result = {
    'name': test_name,
    'input': input_text,
    'model': model,
    'assertions': [],
    'passed': 0,
    'failed': 0,
    'deferred': 0,
    'error': None,
    'output': None,
    'latency_ms': None,
}

# Make API call via the shell helper functions
# We call back into the shell using the exported functions approach
# Instead, we use curl directly here for simplicity
import urllib.request, urllib.error

def call_anthropic(model, system_prompt, user_input, timeout):
    api_key = os.environ.get('ANTHROPIC_API_KEY', '')
    if not api_key:
        raise ValueError('ANTHROPIC_API_KEY not set')

    payload = {
        'model': model,
        'max_tokens': 2048,
        'messages': [{'role': 'user', 'content': user_input}]
    }
    if system_prompt:
        payload['system'] = system_prompt

    req = urllib.request.Request(
        'https://api.anthropic.com/v1/messages',
        data=json.dumps(payload).encode(),
        headers={
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
        },
        method='POST'
    )
    import socket
    socket.setdefaulttimeout(timeout)
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
        return data['content'][0]['text']

def call_openai(model, system_prompt, user_input, timeout):
    api_key = os.environ.get('OPENAI_API_KEY', '')
    if not api_key:
        raise ValueError('OPENAI_API_KEY not set')

    messages = []
    if system_prompt:
        messages.append({'role': 'system', 'content': system_prompt})
    messages.append({'role': 'user', 'content': user_input})

    payload = {'model': model, 'messages': messages, 'max_tokens': 2048}
    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions',
        data=json.dumps(payload).encode(),
        headers={
            'Authorization': f'Bearer {api_key}',
            'content-type': 'application/json',
        },
        method='POST'
    )
    import socket
    socket.setdefaulttimeout(timeout)
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
        return data['choices'][0]['message']['content']

# Determine provider
if model.startswith('claude'):
    call_fn = call_anthropic
elif model.startswith('gpt') or model.startswith('o1') or model.startswith('o3'):
    call_fn = call_openai
else:
    call_fn = call_anthropic

start = time.time()
try:
    output = call_fn(model, system_prompt, input_text, timeout)
    result['latency_ms'] = int((time.time() - start) * 1000)
    result['output'] = output
except Exception as e:
    result['error'] = str(e)
    result['latency_ms'] = int((time.time() - start) * 1000)
    print(json.dumps(result))
    sys.exit(0)

# Evaluate assertions
for assertion in assertions:
    atype = assertion.get('type', '')
    assertion_result = {'type': atype, 'status': None, 'reason': None}

    if atype in ('llm_judge', 'rubric'):
        assertion_result['status'] = 'deferred'
        assertion_result['assertion'] = assertion
        result['deferred'] += 1
    elif atype == 'contains':
        value = assertion.get('value', '')
        ci = assertion.get('case_insensitive', False)
        if (value.lower() in output.lower()) if ci else (value in output):
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"output does not contain '{value}'"
            result['failed'] += 1
    elif atype == 'not_contains':
        value = assertion.get('value', '')
        ci = assertion.get('case_insensitive', False)
        if (value.lower() not in output.lower()) if ci else (value not in output):
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"output contains forbidden string '{value}'"
            result['failed'] += 1
    elif atype == 'exact_match':
        expected = assertion.get('value', '')
        if output.strip() == expected.strip():
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"expected '{expected}', got '{output[:80]}...'"
            result['failed'] += 1
    elif atype == 'fuzzy_match':
        from difflib import SequenceMatcher
        expected = assertion.get('value', '')
        threshold = float(assertion.get('threshold', 0.8))
        ratio = SequenceMatcher(None, output.lower(), expected.lower()).ratio()
        if ratio >= threshold:
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"similarity {ratio:.2f} below threshold {threshold}"
            result['failed'] += 1
    elif atype == 'regex':
        import re
        pattern = assertion.get('pattern', '')
        flags = re.IGNORECASE if assertion.get('case_insensitive', False) else 0
        if re.search(pattern, output, flags):
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"output does not match pattern '{pattern}'"
            result['failed'] += 1
    elif atype == 'json_valid':
        try:
            json.loads(output)
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        except json.JSONDecodeError as e:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"invalid JSON: {e}"
            result['failed'] += 1
    elif atype == 'json_schema':
        try:
            data = json.loads(output)
            schema = assertion.get('schema', {})
            required = schema.get('required', [])
            ok = True
            for field in required:
                if field not in data:
                    assertion_result['status'] = 'fail'
                    assertion_result['reason'] = f"missing required field: {field}"
                    result['failed'] += 1
                    ok = False
                    break
            if ok:
                assertion_result['status'] = 'pass'
                result['passed'] += 1
        except json.JSONDecodeError as e:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"invalid JSON: {e}"
            result['failed'] += 1
    elif atype == 'not_empty':
        if output.strip():
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = 'output is empty'
            result['failed'] += 1
    elif atype == 'max_length':
        limit = int(assertion.get('value', 1000))
        if len(output) <= limit:
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"output length {len(output)} exceeds limit {limit}"
            result['failed'] += 1
    elif atype == 'min_length':
        minimum = int(assertion.get('value', 1))
        if len(output) >= minimum:
            assertion_result['status'] = 'pass'
            result['passed'] += 1
        else:
            assertion_result['status'] = 'fail'
            assertion_result['reason'] = f"output length {len(output)} below minimum {minimum}"
            result['failed'] += 1
    else:
        assertion_result['status'] = 'fail'
        assertion_result['reason'] = f"unknown assertion type: {atype}"
        result['failed'] += 1

    result['assertions'].append(assertion_result)

print(json.dumps(result))

PYEOF "$spec_file" "$test_index" "$model" "$verbose" "$timeout"
}

# ── run command ────────────────────────────────────────────────────────────────
cmd_run() {
    local spec_file=""
    local model="$DEFAULT_MODEL"
    local verbose=false
    local fail_threshold="$DEFAULT_FAIL_THRESHOLD"
    local output_file=""
    local timeout="$DEFAULT_TIMEOUT"
    local dry_run=false

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --model)           model="$2";           shift 2 ;;
            --verbose)         verbose=true;          shift ;;
            --fail-threshold)  fail_threshold="$2";   shift 2 ;;
            --output)          output_file="$2";      shift 2 ;;
            --timeout)         timeout="$2";          shift 2 ;;
            --dry-run)         dry_run=true;          shift ;;
            -*)                die "Unknown option: $1" ;;
            *)
                if [[ -z "$spec_file" ]]; then
                    spec_file="$1"
                fi
                shift ;;
        esac
    done

    [[ -z "$spec_file" ]] && die "No test spec file provided. Usage: prompt-test.sh run <spec.yaml>"
    [[ -f "$spec_file" ]] || die "Test spec not found: $spec_file"

    local suite_name
    suite_name=$(yaml_get "$spec_file" "name" "Unnamed Suite")
    local spec_model
    spec_model=$(yaml_get "$spec_file" "model" "$model")
    # CLI flag takes precedence over spec
    [[ "$model" == "$DEFAULT_MODEL" ]] && model="$spec_model"

    local test_count
    test_count=$(yaml_test_count "$spec_file")

    header "Suite: $suite_name"
    log "Spec:  $spec_file"
    log "Model: $model"
    log "Tests: $test_count"
    echo ""

    if [[ "$dry_run" == "true" ]]; then
        log "Dry run — listing tests:"
        python3 - <<PYEOF "$spec_file"
import yaml, sys
with open(sys.argv[1]) as f:
    spec = yaml.safe_load(f)
for i, t in enumerate(spec.get('tests', [])):
    assertions = [a.get('type') for a in t.get('assertions', [])]
    print(f"  [{i+1}] {t.get('name', f'test_{i}')} ({', '.join(assertions)})")
PYEOF
        return 0
    fi

    local passed=0 failed=0 errors=0 skipped=0
    local results_json="[]"
    local run_timestamp
    run_timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

    # Run each test
    for ((i=0; i<test_count; i++)); do
        local test_name
        test_name=$(python3 -c "
import yaml, sys
with open(sys.argv[1]) as f:
    spec = yaml.safe_load(f)
tests = spec.get('tests', [])
if $i < len(tests):
    print(tests[$i].get('name', f'test_$i'))
else:
    print('test_$i')
" "$spec_file" 2>/dev/null || echo "test_$i")

        printf "  [%d/%d] %-40s" "$((i+1))" "$test_count" "$test_name"

        local result_json
        result_json=$(run_single_test "$spec_file" "$i" "$model" "$verbose" "$timeout" 2>&1)

        if [[ $? -ne 0 ]]; then
            echo -e " ${RED}ERROR${RESET}"
            errors=$((errors + 1))
            continue
        fi

        local test_failed test_error test_latency
        test_failed=$(echo "$result_json" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('failed',0))")
        test_error=$(echo "$result_json" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('error') or '')")
        test_latency=$(echo "$result_json" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('latency_ms') or 0)")

        if [[ -n "$test_error" ]]; then
            echo -e " ${RED}ERROR${RESET} — $test_error"
            errors=$((errors + 1))
        elif [[ "$test_failed" -gt 0 ]]; then
            echo -e " ${RED}FAIL${RESET}  (${test_latency}ms)"
            failed=$((failed + 1))
            if [[ "$verbose" == "true" ]]; then
                echo "$result_json" | python3 -c "
import json,sys
d=json.load(sys.stdin)
for a in d.get('assertions',[]):
    if a.get('status') == 'fail':
        print(f\"    assertion [{a['type']}]: {a.get('reason','')}\")
print(f\"    output: {repr(d.get('output','')[:200])}\")
"
            fi
        else
            echo -e " ${GREEN}PASS${RESET}  (${test_latency}ms)"
            passed=$((passed + 1))
        fi

        # Accumulate results
        results_json=$(echo "$results_json" | python3 -c "
import json,sys
existing = json.load(sys.stdin)
new_item = json.loads(sys.argv[1])
existing.append(new_item)
print(json.dumps(existing))
" "$result_json")
    done

    local total=$((passed + failed + errors))
    local pass_rate=0
    if [[ $total -gt 0 ]]; then
        pass_rate=$(python3 -c "print(round($passed / $total, 4))")
    fi

    echo ""
    echo "─────────────────────────────────────────────────"
    echo -e "  Passed:  ${GREEN}${passed}${RESET}"
    echo -e "  Failed:  ${RED}${failed}${RESET}"
    if [[ $errors -gt 0 ]]; then
        echo -e "  Errors:  ${YELLOW}${errors}${RESET}"
    fi
    echo "  Rate:    $(python3 -c "print(f'{$pass_rate*100:.1f}%')")"
    echo "─────────────────────────────────────────────────"

    # Write output file
    if [[ -n "$output_file" ]] || [[ "${PTF_AUTO_SAVE:-true}" == "true" ]]; then
        local save_file="${output_file}"
        if [[ -z "$save_file" ]]; then
            mkdir -p "$RESULTS_DIR"
            local slug
            slug=$(echo "$suite_name" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | tr -cd '[:alnum:]-')
            save_file="${RESULTS_DIR}/run-${slug}-$(date +%Y%m%d-%H%M%S).json"
        fi

        python3 - <<PYEOF "$save_file" "$suite_name" "$spec_file" "$model" "$run_timestamp"
import json, sys

save_file = sys.argv[1]
results = json.loads('''$results_json''')
report = {
    'suite': sys.argv[2],
    'spec_file': sys.argv[3],
    'model': sys.argv[4],
    'timestamp': sys.argv[5],
    'summary': {
        'total': $total,
        'passed': $passed,
        'failed': $failed,
        'errors': $errors,
        'pass_rate': $pass_rate
    },
    'tests': results
}
with open(save_file, 'w') as f:
    json.dump(report, f, indent=2)
print(save_file)
PYEOF
        log "Results saved: $save_file"
    fi

    # Check fail threshold
    local threshold_pass
    threshold_pass=$(python3 -c "print('yes' if $pass_rate >= $fail_threshold else 'no')")
    if [[ "$threshold_pass" == "no" ]]; then
        echo ""
        fail "Pass rate ${pass_rate} is below threshold ${fail_threshold}"
        exit 1
    fi

    [[ $failed -eq 0 && $errors -eq 0 ]]
}

# ── run-all command ────────────────────────────────────────────────────────────
cmd_run_all() {
    local suite_dir=""
    local extra_args=()

    while [[ $# -gt 0 ]]; do
        case "$1" in
            -*)  extra_args+=("$1" "${2:-}"); shift 2 ;;
            *)
                if [[ -z "$suite_dir" ]]; then
                    suite_dir="$1"
                fi
                shift ;;
        esac
    done

    [[ -z "$suite_dir" ]] && die "No suite directory provided"
    [[ -d "$suite_dir" ]] || die "Suite directory not found: $suite_dir"

    local specs=()
    while IFS= read -r -d '' f; do
        specs+=("$f")
    done < <(find "$suite_dir" -name "test_spec.yaml" -print0 | sort -z)

    if [[ ${#specs[@]} -eq 0 ]]; then
        warn "No test_spec.yaml files found in $suite_dir"
        exit 0
    fi

    header "Running ${#specs[@]} test suite(s)"

    local total_passed=0 total_failed=0 total_errors=0

    for spec in "${specs[@]}"; do
        if cmd_run "$spec" "${extra_args[@]:-}"; then
            total_passed=$((total_passed + 1))
        else
            total_failed=$((total_failed + 1))
        fi
        echo ""
    done

    header "All Suites Summary"
    echo -e "  Suites passed: ${GREEN}${total_passed}${RESET}"
    echo -e "  Suites failed: ${RED}${total_failed}${RESET}"

    [[ $total_failed -eq 0 ]]
}

# ── validate command ───────────────────────────────────────────────────────────
cmd_validate() {
    local spec_file="${1:-}"
    [[ -z "$spec_file" ]] && die "No spec file provided"
    [[ -f "$spec_file" ]] || die "Spec file not found: $spec_file"

    python3 - <<'PYEOF'
import yaml, sys, json

VALID_ASSERTION_TYPES = {
    'contains', 'not_contains', 'exact_match', 'fuzzy_match',
    'regex', 'json_valid', 'json_schema', 'not_empty',
    'max_length', 'min_length', 'llm_judge', 'rubric'
}

errors = []
warnings = []

with open(sys.argv[1]) as f:
    try:
        spec = yaml.safe_load(f)
    except yaml.YAMLError as e:
        print(f"[error] Invalid YAML: {e}")
        sys.exit(1)

if not isinstance(spec, dict):
    errors.append("Spec must be a YAML mapping")

if 'name' not in spec:
    warnings.append("Missing 'name' field")

if 'tests' not in spec:
    errors.append("Missing required 'tests' field")
elif not isinstance(spec['tests'], list) or len(spec['tests']) == 0:
    errors.append("'tests' must be a non-empty list")
else:
    for i, test in enumerate(spec['tests']):
        if not isinstance(test, dict):
            errors.append(f"tests[{i}]: must be a mapping")
            continue
        if 'input' not in test:
            warnings.append(f"tests[{i}] ({test.get('name', '?')}): missing 'input'")
        if 'assertions' not in test or not test['assertions']:
            warnings.append(f"tests[{i}] ({test.get('name', '?')}): no assertions defined")
        else:
            for j, a in enumerate(test.get('assertions', [])):
                atype = a.get('type', '')
                if atype not in VALID_ASSERTION_TYPES:
                    errors.append(f"tests[{i}].assertions[{j}]: unknown type '{atype}'")
                if atype == 'llm_judge' and 'criteria' not in a:
                    errors.append(f"tests[{i}].assertions[{j}]: llm_judge requires 'criteria'")
                if atype in ('contains', 'not_contains', 'exact_match') and 'value' not in a:
                    errors.append(f"tests[{i}].assertions[{j}]: {atype} requires 'value'")
                if atype == 'regex' and 'pattern' not in a:
                    errors.append(f"tests[{i}].assertions[{j}]: regex requires 'pattern'")

for w in warnings:
    print(f"[warn]  {w}")
for e in errors:
    print(f"[error] {e}")

if errors:
    print(f"\nValidation FAILED ({len(errors)} errors, {len(warnings)} warnings)")
    sys.exit(1)
else:
    test_count = len(spec.get('tests', []))
    print(f"[ok] Valid spec — {test_count} test(s)")
    if warnings:
        print(f"     ({len(warnings)} warnings)")
PYEOF "$spec_file"
}

# ── list command ──────────────────────────────────────────────────────────────
cmd_list() {
    local spec_file="${1:-}"
    [[ -z "$spec_file" ]] && die "No spec file provided"
    [[ -f "$spec_file" ]] || die "Spec file not found: $spec_file"

    python3 - <<'PYEOF'
import yaml, sys

with open(sys.argv[1]) as f:
    spec = yaml.safe_load(f)

name = spec.get('name', 'Unnamed')
model = spec.get('model', 'default')
tests = spec.get('tests', [])
print(f"Suite: {name}")
print(f"Model: {model}")
print(f"Tests: {len(tests)}")
print()
for i, t in enumerate(tests):
    assertions = [a.get('type', '?') for a in t.get('assertions', [])]
    print(f"  [{i+1:2d}] {t.get('name', f'test_{i}'):<40} [{', '.join(assertions)}]")
PYEOF "$spec_file"
}

# ── help ──────────────────────────────────────────────────────────────────────
cmd_help() {
    cat <<EOF
${BOLD}prompt-test${RESET} v${VERSION} — Prompt Testing Framework CLI

${BOLD}USAGE${RESET}
  prompt-test.sh <command> [options]

${BOLD}COMMANDS${RESET}
  run <spec.yaml>           Run a single test suite
  run-all <dir/>            Run all test_spec.yaml files in a directory
  validate <spec.yaml>      Validate a test spec without running it
  list <spec.yaml>          List tests in a spec file
  help                      Show this help

${BOLD}RUN OPTIONS${RESET}
  --model <model>           Override model (default: $DEFAULT_MODEL)
  --verbose                 Print full output and assertion details
  --fail-threshold <0-1>    Fail if pass rate below threshold (default: 1.0)
  --output <file>           Write JSON results to file
  --timeout <seconds>       Per-request timeout (default: $DEFAULT_TIMEOUT)
  --dry-run                 List tests without executing

${BOLD}ENVIRONMENT${RESET}
  ANTHROPIC_API_KEY         Required for Claude models
  OPENAI_API_KEY            Required for GPT models
  PTF_RESULTS_DIR           Directory for results output (default: ./results)

${BOLD}EXAMPLES${RESET}
  ./framework/prompt-test.sh run test-suites/accuracy/test_spec.yaml
  ./framework/prompt-test.sh run test-suites/accuracy/test_spec.yaml --verbose
  ./framework/prompt-test.sh run-all test-suites/ --fail-threshold 0.9
  ./framework/prompt-test.sh validate test-suites/edge-cases/test_spec.yaml
  ./framework/prompt-test.sh list test-suites/accuracy/test_spec.yaml

${BOLD}MODELS${RESET}
  claude-3-5-haiku-20241022    Fast, cheap (default)
  claude-3-5-sonnet-20241022   Balanced
  claude-opus-4-5              Most capable
  gpt-4o-mini                  OpenAI fast
  gpt-4o                       OpenAI capable

EOF
}

# ── Entry point ────────────────────────────────────────────────────────────────
main() {
    check_deps

    local command="${1:-help}"
    shift || true

    case "$command" in
        run)       cmd_run "$@" ;;
        run-all)   cmd_run_all "$@" ;;
        validate)  cmd_validate "$@" ;;
        list)      cmd_list "$@" ;;
        help|-h|--help) cmd_help ;;
        version|-v|--version) echo "prompt-test v$VERSION" ;;
        *) die "Unknown command: $command. Run 'prompt-test.sh help' for usage." ;;
    esac
}

main "$@"
