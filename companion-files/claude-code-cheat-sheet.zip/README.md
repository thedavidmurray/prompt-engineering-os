# Claude Code Cheat Sheet

**Tier 1 product — Free or $5 | Edgeless Labs LLC**

A beautifully designed, print-ready one-page reference for Claude Code. Everything a developer needs to work effectively with Claude Code — CLI flags, slash commands, CLAUDE.md structure, hooks, subagents, skills, MCP servers, keyboard shortcuts, and permission modes — compressed into a single printable sheet.

---

## What's Included

| File | Description |
|------|-------------|
| `claude-code-cheat-sheet.html` | Self-contained HTML — open in browser, print to PDF |
| `LICENSE` | MIT License |
| `README.md` | This file |

---

## How to Use

### Print to PDF (recommended)

1. Open `claude-code-cheat-sheet.html` in Chrome or Firefox
2. Press `Cmd+P` (macOS) or `Ctrl+P` (Windows/Linux)
3. Set destination to "Save as PDF"
4. Set paper size to A4 or Letter
5. Disable headers/footers in "More settings"
6. Print (2 pages at default zoom)

### Pin next to your monitor

Print at 85–90% scale to fit on a single page if your printer supports it, or print at 100% for maximum readability across 2 pages.

### Dark theme on screen

The HTML renders in dark mode on screen and automatically switches to a clean light theme when printing.

---

## Sections Covered

- **CLI Commands** — all major flags and one-shot / pipe modes
- **Slash Commands** — in-session commands with descriptions
- **CLAUDE.md Files** — load order, locations, what each scope does
- **Hooks** — event types, config format, decision return values
- **Subagents** — types, key parameters, isolation options
- **Skills** — location convention, format, invocation
- **MCP Servers** — config format for project and global scope
- **Keyboard Shortcuts** — context insertion, interruption, multiline
- **Permission Modes** — default, whitelist, and skip-all patterns

---

## Who This Is For

- Developers new to Claude Code who want a fast orientation
- Experienced users who keep forgetting the exact flag syntax
- Teams onboarding engineers to an AI-assisted workflow
- Anyone who learns better from a physical reference than docs

---

## Distribution

| Channel | Price |
|---------|-------|
| Gumroad | Free / Pay what you want |
| Payhip | $5 |
| GitHub (repo) | Free (MIT) |

---

## License

MIT — see `LICENSE`. Free to use, modify, and redistribute with attribution.

---

*Product of Edgeless Labs LLC | edgeless.ai*
